<?php
$conn = mysqli_connect("localhost", "root", "", "qz") or die("could not connect" . mysqli_error($conn) ) ;
?>
